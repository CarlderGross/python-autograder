def go( a, b ):
  #add your code here
  if a > b and a % 2 == 1:
      return "yes"
  if b > a and b % 2 == 1:
      return "no"
  if a==b and a % 2 == 0 and b % 2 == 0:
      return "aplus"
  return "compsci"

  
#add test cases

with open('unit1assmt1.dat') as f:
    line = f.readline()
    while line:
        #print(line, end='')
        line = f.readline()
        
        if len(line.split()) > 0:
            print(go(int((line.split()[0])), int((line.split()[1]))))