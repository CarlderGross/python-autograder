def go( a, b ):
  if a + b >= 20:
      if a == b:
          return "aplus"
      if a != b:
          return "compsci"
  else:
      if a < b:
          return "no"
      if b < a:
          return "yes"
      else:
          return "maybe"
  
  
#add test cases

with open('unit1assmt1.dat') as f:
    line = f.readline()
    while line:
        #print(line, end='')
        line = f.readline()
        
        if len(line.split()) > 0:
            print(go(int((line.split()[0])), int((line.split()[1]))))