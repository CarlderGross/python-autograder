def go( a, b ):
  if a>b:
      return "yes"
  if a<b:
      return "no"
  if a==b:
      return "aplus"
  else:
    return "compsci"
  
  
#add test cases

with open('unit1assmt1.dat') as f:
    line = f.readline()
    while line:
        #print(line, end='')
        line = f.readline()
        
        if len(line.split()) > 0:
            print(go(int((line.split()[0])), int((line.split()[1]))))