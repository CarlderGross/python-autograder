def is_odd(a: int) -> bool: return a % 2 != 0
def is_even(a: int) -> bool: return not is_odd(a)

def go(a: int, b: int) -> str:
    if a > b and is_odd(a):
        return "yes"
    elif b > a and is_odd(b):
        return "no"
    elif a == b and is_even(b) and is_even(a):
        return "aplus"
    return "compsci"

if __name__ == "__main__":
    with open('unit1assmt1.dat') as f:
        line = f.readline()
        while line:
            spl = line.split()
            if len(spl) > 0:
                g = go(int(spl[0]), int(spl[1]))
                print(g)
                if len(spl) > 2: assert g == spl[2]
            line = f.readline()