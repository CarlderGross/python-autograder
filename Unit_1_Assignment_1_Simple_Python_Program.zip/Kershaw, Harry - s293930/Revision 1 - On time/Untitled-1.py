
def go( a, b ):
  if a>b and a%2 == 1:
    return "yes"
  elif b>a and b%2 == 1:
     return "no"
  elif a==b and a%2 == 0:
     return "aplus"
  else:
    return "compsci"
  
  
#add test cases

with open('unit1assmt1.dat') as f:
    line = f.readline()
    while line:
        #print(line, end='')
        
        if len(line.split()) > 0:
            print(go(int((line.split()[0])), int((line.split()[1]))))
        line = f.readline()