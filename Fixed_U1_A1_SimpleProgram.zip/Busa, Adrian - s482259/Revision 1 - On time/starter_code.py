def go( a, b ):
  #add your code here
  
  return "compsci"
  
  
#add test cases

with open('unit1assmt1.dat') as f:
    line = f.readline()
    while line:
        #print(line, end='')
        line = f.readline()
        
        if len(line.split()) > 0:
            print(go(int((line.split()[0])), int((line.split()[1]))))