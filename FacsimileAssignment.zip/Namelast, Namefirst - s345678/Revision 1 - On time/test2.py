num = input("Input a number: ")
out = int(num) + 1
print("Your result is "+out)