while True:
    num = input("Input a number: ")
    out = int(num) + 1
    print(out)