while True:
    num = input("Input a number: ")
    out = int(num) + 1
    if (out == 3):
        out = 100
    print(out)